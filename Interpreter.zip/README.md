# Scheme-Interpreter
CS304 Project: Scheme Interpreter

This is a metacircular evaluator of Scheme, that is, we use Scheme to evaluate Scheme!
